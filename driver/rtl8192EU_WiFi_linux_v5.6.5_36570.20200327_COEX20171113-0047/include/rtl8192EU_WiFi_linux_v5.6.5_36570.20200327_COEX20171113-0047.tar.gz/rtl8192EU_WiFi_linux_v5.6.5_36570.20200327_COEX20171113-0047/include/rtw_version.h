#define DRIVERVERSION	"rtl8192eu v5.6.3.1.1_34030.20190826_remove_deny_scan_condition"
#define BTCOEXVERSION	"COEX20171113-0047"
